
<!DOCTYPE html>
<html>
<head>
<title>Food Truck Order Form</title>
<link href="css/stylesheet.css" type="text/css" rel="stylesheet" />

</head>
   
<body> <!-- checks for cookies here -->

    <img src="img/food-truck.jpg">
    
    <div id="welcome">
     <h1>Welcome to <b style="color:blue">&#9832;</b> Yummy</h1>
     <h1>Food Truck</h1>
       </div>    

<table>
<tr>
    <td><h1> <b style="color:green">Thank you for purchased today! </b></h1></td>


</tr>

</table>


    

</body>
</html>
